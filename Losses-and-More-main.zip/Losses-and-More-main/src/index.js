require('dotenv').config();
const { Client, Collection, GatewayIntentBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const logger = require('./utils/logger');
const config = require('./utils/config');
const LogScheduler = require('./utils/logScheduler');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent
  ]
});

// Initialize log scheduler
const logScheduler = new LogScheduler(client);

// Initialize key health checker
const KeyHealthChecker = require('./utils/keyHealthChecker');
const keyHealthChecker = new KeyHealthChecker(client);

// Load commands
client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  client.commands.set(command.data.name, command);
  logger.info(`[BOT] Loaded command: ${command.data.name}`);
}

// Load events
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
  const filePath = path.join(eventsPath, file);
  const event = require(filePath);
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args));
  } else {
    client.on(event.name, (...args) => event.execute(...args));
  }
  logger.info(`[BOT] Loaded event: ${event.name}`);
}

client.login(config.discordToken)
  .then(() => {
    logger.info('[BOT] Login initiated');

    // Start log scheduler after successful login
    logScheduler.start();

    // Start key health checker after successful login
    keyHealthChecker.start();
  })
  .catch(err => {
    logger.error(`[BOT] Login failed: ${err.message}`);
    process.exit(1);
  });

process.on('uncaughtException', (err) => {
  logger.error(`[BOT] Uncaught Exception: ${err}`);
  process.exit(1);
});

process.on('unhandledRejection', (err) => {
  logger.error(`[BOT] Unhandled Rejection: ${err}`);
});